import Attendance from '../models/Attendance.js';
import AttendanceRequest from '../models/AttendanceRequest.js';
import mongoose from 'mongoose';

/**
 * Mark Initial Attendance
 */
export const markAttendance = async (req, res) => {
  try {
    const { classroom, timetableEntry, faculty, date, dateString, records } =
      req.body;

    // The unique index in schema handles the "already marked" check,
    // but we can catch it gracefully.
    const newAttendance = new Attendance({
      classroom,
      timetableEntry,
      faculty,
      date,
      dateString,
      records,
      isLocked: true // Locked immediately per your schema
    });

    await newAttendance.save();
    res.status(201).json({ success: true, data: newAttendance });
  } catch (error) {
    if (error.code === 11000) {
      return res
        .status(400)
        .json({
          success: false,
          message: 'Attendance already marked for this slot.'
        });
    }
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * Faculty creates a request to change locked attendance
 */
export const requestAttendanceChange = async (req, res) => {
  try {
    const { attendanceId, requestedChanges, reason } = req.body;
    const facultyId = req.user._id; // Assuming auth middleware

    const request = new AttendanceRequest({
      attendanceRecord: attendanceId,
      faculty: facultyId,
      requestedChanges,
      reason,
      approvalStatus: 'Pending'
    });

    await request.save();
    res
      .status(201)
      .json({
        success: true,
        message: 'Change request submitted to HOD',
        data: request
      });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * HOD Approval/Rejection Logic
 */
export const resolveAttendanceRequest = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { requestId, status, reviewRemarks } = req.body;
    const hodId = req.user._id;

    const request =
      await AttendanceRequest.findById(requestId).session(session);
    if (!request || request.approvalStatus !== 'Pending') {
      throw new Error('Request not found or already resolved.');
    }

    request.approvalStatus = status;
    request.reviewedBy = hodId;
    request.reviewRemarks = reviewRemarks;
    request.resolvedAt = new Date();

    if (status === 'Approved') {
      const attendance = await Attendance.findById(
        request.attendanceRecord
      ).session(session);

      // Update individual student records within the attendance sheet
      request.requestedChanges.forEach((change) => {
        const recordIndex = attendance.records.findIndex(
          (r) => r.student.toString() === change.student.toString()
        );
        if (recordIndex !== -1) {
          attendance.records[recordIndex].status = change.newStatus;
        }
      });

      attendance.status = 'UPDATED_BY_HOD';
      await attendance.save({ session });
    }

    await request.save({ session });
    await session.commitTransaction();

    res.status(200).json({ success: true, message: `Request ${status}` });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

/**
 * Get Attendance for a specific classroom and date
 */
export const getAttendanceByClassroom = async (req, res) => {
  try {
    const { classroomId, dateString } = req.query;
    const data = await Attendance.findOne({
      classroom: classroomId,
      dateString
    }).populate('records.student', 'name rollNumber');
    res.status(200).json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
